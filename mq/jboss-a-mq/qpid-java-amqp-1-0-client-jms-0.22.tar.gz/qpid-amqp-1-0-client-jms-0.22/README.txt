Documentation
=============

You can access documentation for the client via our website at:
http://qpid.apache.org/documentation

and via our wiki at:
http://cwiki.apache.org/confluence/display/qpid/Qpid+Java+Documentation

The client uses the Java Message Service (JMS) 1.1 API, information on which is
widely available using your favoured search engine.

